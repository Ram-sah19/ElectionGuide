// ─────────────────────────────────────────────
//  ElectionGuide AI – API Configuration
//  DO NOT commit this file (it is gitignored)
//  Paste your OpenAI API key below
// ─────────────────────────────────────────────
const OPENAI_API_KEY = "sk-abcdef1234567890abcdef1234567890abcdef12"
